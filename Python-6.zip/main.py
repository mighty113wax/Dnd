import discord
from discord.ext import commands
import random
import json
import os
import time
from flask import Flask
from threading import Thread

# Bestandsnamen voor gegevens
BALANCE_FILE = "balances.json"
COOLDOWN_FILE = "cooldowns.json"

# Kleur voor de embeds
EMBED_COLOR = 0x800080  # Paars

# Laad gegevens uit bestanden
def load_data():
    global user_balances, work_cooldowns
    if os.path.exists(BALANCE_FILE):
        with open(BALANCE_FILE, "r") as f:
            user_balances = json.load(f)
    else:
        user_balances = {}
        
    if os.path.exists(COOLDOWN_FILE):
        with open(COOLDOWN_FILE, "r") as f:
            work_cooldowns = json.load(f)
    else:
        work_cooldowns = {}

# Sla gegevens op in bestanden
def save_data():
    with open(BALANCE_FILE, "w") as f:
        json.dump(user_balances, f)
    with open(COOLDOWN_FILE, "w") as f:
        json.dump(work_cooldowns, f)

# Initializeer de bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=None, intents=intents)

OWNER_ID = 1157996327129579620  # Vervang dit door je eigen Discord User ID

@bot.event
async def on_ready():
    print(f'Bot is online as {bot.user}!')
    load_data()  # Laad gegevens bij opstarten
    
    # Zorg ervoor dat slash commands worden gesynchroniseerd
    try:
        await bot.tree.sync()
        print("Slash commands synced with Discord.")
    except Exception as e:
        print(f"Error syncing commands: {e}")

# Definieer slash commands
@bot.tree.command(name="balance", description="Check your coin balance")
async def balance(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    balance = user_balances.get(user_id, 0)
    embed = discord.Embed(title="Balance", description=f"{interaction.user.mention}, you have {balance} coins.", color=EMBED_COLOR)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="lottery", description="Participate in the lottery (costs 50 coins)")
async def lottery(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    balance = user_balances.get(user_id, 0)
    if balance < 50:
        embed = discord.Embed(title="Lottery", description=f"{interaction.user.mention}, you don't have enough coins to enter the lottery. You need at least 50 coins.", color=EMBED_COLOR)
        await interaction.response.send_message(embed=embed)
        return

    user_balances[user_id] -= 50
    result = random.randint(-200, 400)
    user_balances[user_id] += result
    save_data()

    embed = discord.Embed(
        title="Lottery Result",
        description=f"{interaction.user.mention}, you {'won' if result >= 0 else 'lost'} {abs(result)} coins!",
        color=EMBED_COLOR
    )
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="give", description="Give coins to another user")
async def give(interaction: discord.Interaction, amount: int, member: discord.Member):
    giver_id = str(interaction.user.id)
    recipient_id = str(member.id)
    
    # Zorg ervoor dat het bedrag geldig is
    if amount == 0:
        embed = discord.Embed(title="Give Coins", description=f"{interaction.user.mention}, you cannot give 0 coins.", color=EMBED_COLOR)
        await interaction.response.send_message(embed=embed)
        return
    
    # Als de bot-eigenaar de command uitvoert
    if giver_id == str(OWNER_ID):
        if amount < 0:
            # Munten afnemen
            user_balances[recipient_id] = max(0, user_balances.get(recipient_id, 0) + amount)
            description = f"You have taken {-amount} coins from {member.mention}."
        else:
            # Munten toevoegen
            user_balances[recipient_id] = user_balances.get(recipient_id, 0) + amount
            description = f"You have given {amount} coins to {member.mention}."
        
        save_data()
        embed = discord.Embed(title="Give Coins", description=description, color=EMBED_COLOR)
        await interaction.response.send_message(embed=embed)
    
    else:
        # Zorg ervoor dat normale gebruikers alleen positieve bedragen kunnen geven
        if amount <= 0:
            embed = discord.Embed(title="Give Coins", description=f"{interaction.user.mention}, you can only give a positive number of coins.", color=EMBED_COLOR)
            await interaction.response.send_message(embed=embed)
            return
        
        # Controleer of de gebruiker genoeg munten heeft
        balance = user_balances.get(giver_id, 0)
        if balance < amount:
            embed = discord.Embed(title="Give Coins", description=f"{interaction.user.mention}, you don't have enough coins to give.", color=EMBED_COLOR)
            await interaction.response.send_message(embed=embed)
            return
        
        # Munten overdragen
        user_balances[giver_id] -= amount
        user_balances[recipient_id] = user_balances.get(recipient_id, 0) + amount
        save_data()
        
        embed = discord.Embed(title="Give Coins", description=f"{interaction.user.mention}, you have given {amount} coins to {member.mention}.", color=EMBED_COLOR)
        await interaction.response.send_message(embed=embed)

@bot.tree.command(name="work", description="Earn coins by working")
async def work(interaction: discord.Interaction):
    current_time = time.time()
    user_id = str(interaction.user.id)

    if user_id in work_cooldowns:
        last_work_time = work_cooldowns[user_id]
        cooldown = 30
        time_remaining = int(cooldown - (current_time - last_work_time))

        if time_remaining > 0:
            embed = discord.Embed(title="Work", description=f"{interaction.user.mention}, you need to wait {time_remaining} more seconds before you can work again.", color=EMBED_COLOR)
            await interaction.response.send_message(embed=embed)
            return

    earnings = random.randint(1, 20)
    user_balances[user_id] = user_balances.get(user_id, 0) + earnings
    work_cooldowns[user_id] = current_time
    save_data()

    embed = discord.Embed(title="Work", description=f"{interaction.user.mention}, you earned {earnings} coins from working.", color=EMBED_COLOR)
    await interaction.response.send_message(embed=embed)

# Simpele webserver om de bot actief te houden op Replit
app = Flask(__name__)